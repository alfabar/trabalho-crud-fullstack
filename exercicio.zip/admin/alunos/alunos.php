<?php



$alunos = [
    "1" => [
        "nome" => "Maria",
        "p_nota" => 16,
        "s_nota" => 85,
        "media" => 155

    ],

    "2" => [
        "nome" => "Artur",
        "p_nota" => 1,6,
        "s_nota" => 9,2,
        "media" => 5

    ],

    "3" => [
        "nome" => "Gustavo",
        "p_nota" => 16,
        "s_nota" => 80,
        "media" => 92

    ],

    "4" => [
        "nome" => "Isabela",
        "p_nota" => 17,
        "s_nota" => 20,
        "media" => 92

    ],
   [
        "nome" => "Kelly",
        "p_nota" => 17,
        "s_nota" => 100,
        "media" => 92

    ],

     [
        "nome" => "Paulo",
        "p_nota" => 16,
        "s_nota" => 85,
        "media" => 92

    ],

    [
        "nome" => "Gabriel",
        "p_nota" => 16,
        "s_nota" => 80,
        "media" => 92

    ],

     [
        "nome" => "Mateus",
        "p_nota" => 16,
        "s_nota" => 83,
        "media" => 92

    ],

     [
        "nome" => "Bruna",
        "p_nota" => 16,
        "s_nota" => 90,
        "media" => 92

    ],


];